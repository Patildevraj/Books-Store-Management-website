import React from 'react'
import { Link } from 'react-router-dom'
import { BsArrowLeft } from 'react-icons/bs'

const BackButton = ({ destination = "/" }) => {
    return (
        <>
            <div>
                <button className='btn btn-outline-info my-2'>
                    <Link to={destination} >
                        <BsArrowLeft className='fs-1' />
                    </Link>
                </button>
            </div>
        </>
    )
}

export default BackButton