import BookSingleCard from "./BookSingleCard"

const BooksCard = ({ books }) => {
    return (
        <>
            <div className="container-fluid">
                <div className="row shadow">
                    {
                        books.map((item) => (
                            <BookSingleCard book={item} key={item._id}/>
                        ))
                    }
                </div>
            </div>
        </>
    )
}

export default BooksCard