import React, { useState } from 'react'
import BackButton from '../components/BackButton'
import Spinner from '../components/Spinner'
import axios from 'axios'
import { useNavigate, useParams } from 'react-router-dom'
import { useSnackbar } from 'notistack'


const DeleteBook = () => {
  const [loading, setLoading] = useState(false)
  const { id } = useParams();
  const navigate = useNavigate();
  const {enqueueSnackbar} =useSnackbar()


  const handleDeleteBook = () => {
    setLoading(true)
    axios.delete(`http://localhost:3000/books/${id}`)
      .then(() => {
        setLoading(false)
        enqueueSnackbar('Book Deleted Successfully',{variant:'success'})
        navigate('/')
      })
      .catch((error) => {
        setLoading(false)
        alert('Data is not deleted')
        enqueueSnackbar('Error Occured',{variant:'error'})
        console.log(error);
      })
  }
  return (
    <>
      <div className="container">
        <div className="row">
          <BackButton />
          <h1>Edit Book</h1>
        </div>
        {loading ? <Spinner /> : ''}

        <div className="row">
          <div className="col-3"></div>
          <div className="col-6">
            <div className='border rounded p-4 border-danger'>
              <h3>Are you sure ,you want to delete this button ?</h3>
              <button className='btn btn-danger text-light w-100 m-auto mt-3' onClick={handleDeleteBook}>Yes ,Delete it !</button>
            </div>
          </div>
          <div className="col-3"></div>
        </div>
      </div>
    </>
  )
}

export default DeleteBook