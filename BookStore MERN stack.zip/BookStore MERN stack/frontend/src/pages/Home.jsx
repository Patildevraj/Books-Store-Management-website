import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { MdOutlineAddBox } from 'react-icons/md'
import Spinner from '../components/Spinner'
import BooksCard from '../components/home/BooksCard'
import BooksTable from '../components/home/BooksTable'


const Home = () => {
    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showType, setShowType] = useState('div.table')

    const fetchData = async () => {
        setLoading(true)
        try {
            const response = await axios.get('http://localhost:3000/books');
            setBooks(response.data.data);
            setLoading(false)

            // console.log("Response ",response.data.data)
        }
        catch (err) {
            console.log(err);
            setLoading(false)
        }
    }


    useEffect(() => {
        fetchData();
    }, [])
    // console.log(books, "nnnnnnnn");

    return (
        <>
            <section className="container-fluid p-4">

                <div className="row">
                    <div className="butttons text-center">
                        <button className='btn btn-info px-3 text-white border-0 shadow-lg rounded-5 fs-5 me-2' onClick={() => { setShowType('div.table') }}>Table Format</button>
                        <button className='btn btn-info px-3 text-white border-0 shadow-lg rounded-5 fs-5' onClick={() => { setShowType('div.card') }}>Card Format</button>
                    </div>
                </div>

                <div className="row px-4 pt-3">
                    <div className="col-12 d-flex justify-content-between border-bottom border-info mb-3 shadow">
                        <h1>Books List</h1>
                        <Link to='/books/create'>
                            <MdOutlineAddBox className='fs-1 text-success mt-2' />
                        </Link>
                    </div>
                </div>
                {
                    loading ?
                        <Spinner />
                        : showType === 'div.table' ? (<BooksTable books={books} />) : (<BooksCard books={books} />)
                }

            </section>
        </>
    )
}

export default Home