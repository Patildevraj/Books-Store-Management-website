import express from 'express';
import { Book } from '../models/BookModel.js';

const router = express.Router()

// route for saving a book
router.post('/books', async (request, response) => {
    try {
        if (
            !request.body.title ||
            !request.body.author ||
            !request.body.publishYear
        ) {
            return response.status(400).send({
                message: 'send all required fields'
            })
        }
        const newBook = {
            title: request.body.title,
            author: request.body.author,
            publishYear: request.body.publishYear
        }
        const book = await Book.create(newBook);

        return response.status(201).send(book)
    } catch (error) {
        return response.status(400).send(error.message)
    }
})

// Route for getting all the books
router.get('/books', async (request, response) => {
    try {
        const book = await Book.find({})
        return response.status(200).json({
            count: book.length, data: book
        })

    } catch (error) {
        // console.log(error.message);
        response.status(500).send({ message: error.message })
    }
})

// Route for getting one books
router.get('/books/:id', async (request, response) => {
    try {
        const id=request.params.id;
        const book = await Book.find({_id: id})
        // console.log(book, "----------------")
        return response.status(200).json(book)

    } catch (error) {
        // console.log(error.message);
        response.status(500).send({ message: error.message })
    }
})

// Route for update a book
router.put('/books/:id', async (request, response) => {
    try {
        
        const id = request.params.id;
        const result = await Book.findByIdAndUpdate({_id: id}, request.body)
        // console.log(request.body, "lllllllllllllll")

        
        return response.status(200).send(result)
    } catch (error) {
        return response.status(400).send({ message: error.message })
    }
})

// Route for deleting a book
router.delete('/books/:id', async(request, response) => {
try {
    const result = await Book.deleteOne({_id: request.params.id})
    if(!result){
        return response.send(404).json({message:error.message})
    }
    return response.status(200).json('Book deleted successfully')
    
} catch (error) {
    return response.status(400).send({ message: error.message })
}
})


export default router;