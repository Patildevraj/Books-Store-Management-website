import React, { useState } from 'react'
import { PiBookOpenTextLight } from 'react-icons/pi'
import { Link } from 'react-router-dom'
import { BiUserCircle } from 'react-icons/bi'
import { AiOutlineEdit } from 'react-icons/ai'
import { BsInfoCircle } from 'react-icons/bs'
import { MdDelete } from "react-icons/md";
import BookModal from './BookModal'
import { BiShow } from 'react-icons/bi'
import '../custom.css'

const BookSingleCard = ({ book }) => {
    const [showModal, setShowModal] = useState(false);

    return (
        <>
            <div className="col-3 g-2" key={book._id}>
                <div className="card shadow">
                    <div className="card-body">
                        <div className="d-flex justify-content-between">
                            <p><strong>Id </strong>: {book._id}</p>
                            <p className='bg-warning rounded px-1 shadow'>{book.publishYear}</p>
                        </div>
                        <hr />
                        <div className='d-flex pb-2'>
                            <span className='me-2 text-info-emphasis'><PiBookOpenTextLight className='fs-4' /></span><h5 className="card-title">Title : {book.title}</h5>
                        </div>
                        <div className="d-flex">
                            <span className='me-2 text-info-emphasis'><BiUserCircle className='fs-4' /></span><p className="card-text">Author : {book.author}</p>
                        </div>
                        <hr />
                        <div className="d-flex justify-content-between">
                            <button onClick={()=>setShowModal(true)}  className='showButton border-0 bg-0' type='button' data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                <BiShow className='fs-3 text-info bg-0' />
                            </button>
                            {
                                showModal &&
                                <BookModal showModal={showModal} book={book}/>
                            }
                            <Link to={`/books/details/${book._id}`}>
                                <BsInfoCircle className='fs-4 mx-2 text-success' data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Tooltip on bottom" />
                            </Link>
                            <Link to={`/books/edit/${book._id}`}>
                                <AiOutlineEdit className='fs-4 mx-2 text-warning' />
                            </Link>
                            <Link to={`/books/delete/${book._id}`}>
                                <MdDelete className='fs-4 mx-2 text-danger' />
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default BookSingleCard