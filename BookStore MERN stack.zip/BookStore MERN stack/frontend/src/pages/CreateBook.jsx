import React, { useState } from 'react'
import BackButton from '../components/BackButton'
import Spinner from '../components/Spinner'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom'
import { useSnackbar } from 'notistack'

const CreateBook = () => {
  const [title, setTitle] = useState('')
  const [author, setAuthor] = useState('')
  const [publishYear, setPublishYear] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate();
  const {enqueueSnackbar} = useSnackbar()

  const handleSaveBook = () => {
    const data = {
      title, author, publishYear
    };
    setLoading(true)
    axios.post('http://localhost:3000/books', data)
      .then(() => {
        setLoading(false)
        enqueueSnackbar('Book Created Successfully',{variant:'success'})
        navigate('/')

      }).catch((error) => {
        setLoading(false)
        alert('error found please go to console')
        enqueueSnackbar('Error Occured',{variant:'error'})
        console.log(error);
      })
  }

  return (
    <>
      <div className="container">
        <div className="row">
          <BackButton />
          <h1>Create Book</h1>
        </div>
        {loading ? <Spinner /> : ''}
        <div className="row">
          <div className="col-3"></div>
          <div className="col-6">
            <form action="" className='border rounded p-4 border-info'>
              <div className="mb-3">
                <label htmlFor="title" className="form-label">Title</label>
                <input
                  type="text"
                  className="form-control border-2"
                  id="title"
                  placeholder="Enter title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="author" className="form-label">Author</label>
                <input
                  type="text"
                  className="form-control border-2"
                  id="author"
                  placeholder="Enter author name"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="publishYear" className="form-label">PublishYear</label>
                <input
                  type="number"
                  className="form-control"
                  id="publishYear"
                  placeholder="Enter publish year"
                  value={publishYear}
                  onChange={(e) => setPublishYear(e.target.value)}
                />
              </div>
              <div className='mb-1 m-auto'>
                <Link to='/'><button type="submit" onClick={handleSaveBook} className='btn btn-info w-100'>Save</button></Link>
              </div>
            </form>
          </div>
          <div className="col-3"></div>
        </div>
      </div>
    </>
  )
}

export default CreateBook