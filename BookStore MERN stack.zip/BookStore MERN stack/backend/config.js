export const PORT = 3000;

export const mongoDBURL = 'mongodb+srv://Devraj:pass123@cluster0.qcyio4s.mongodb.net/Cluster0?retryWrites=true&w=majority';