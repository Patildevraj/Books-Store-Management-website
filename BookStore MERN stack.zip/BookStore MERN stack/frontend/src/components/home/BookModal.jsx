import React from 'react'
import { PiBookOpenTextLight } from 'react-icons/pi'
import { BiUserCircle } from 'react-icons/bi'
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';

function BookModal({ showModal, book }) {
    const [show, setShow] = useState(showModal);

    const handleClose = () => setShow(false);


    return (

        <>
            {/* {console.log(book, "dddddd")} */}
            <Modal show={show} onHide={handleClose} animation={false} className='w-100' centered>
                <Modal.Header closeButton>
                    <h5 className='bg-warning rounded-5 p-2 shadow'>Publish Year: {book.publishYear}</h5>
                </Modal.Header>
                <Modal.Body>
                    <div>
                        <h6 className='pb-2'><span className='me-3'>ID:</span> {book._id}</h6>
                    </div>
                    <div className='d-flex pb-2'>
                        <span className='me-3 text-info-emphasis'><PiBookOpenTextLight className='fs-4' /></span><h4 className="card-title">Title : {book.title}</h4>
                    </div>
                    <div className="d-flex">
                        <span className='me-3 text-info-emphasis'><BiUserCircle className='fs-4' /></span><h4 className="card-text">Author : {book.author}</h4>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <h6>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Necessitatibus dicta ipsam id earum consequatur exercitationem tempora voluptates, nisi omnis cum nesciunt non autem distinctio officiis.</h6>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default BookModal;