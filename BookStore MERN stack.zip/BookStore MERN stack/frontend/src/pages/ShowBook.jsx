import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams } from 'react-router-dom';
import BackButton from '../components/BackButton';
import Spinner from '../components/Spinner';

const ShowBook = () => {

  const [book, setBook] = useState({});
  const [loading, setLoading] = useState(false);

  const { id } = useParams();

  useEffect(() => {
    setLoading(true)
    axios.get(`http://localhost:3000/books/${id}`)
      .then((response) => {
        console.log(response, id, "iiiiiiiiiiiiiii")
        setBook(response.data[0])
        setLoading(false)
      }).catch((error) => {
        console.log(error);
        setLoading(false)
      })
  }, [])


  return (
    <>
      <div className="container">
        <div className="row">
          <BackButton />
          <h1 className='text-center border-bottom'>ShowBook</h1>
        </div>
        {loading ? (
          <>
            <Spinner />
          </>
        ) : (
          <>
            <div className="card w-100 m-auto mt-3">
              <div className="card-body">
                <table className='table border-light'>
                  <tbody>
                    <tr>
                      <td className='card-text'><h5>Id:</h5></td>
                      <td><h5 className="card-text"> {book._id}</h5></td>
                    </tr>
                    <tr>
                      <td className='card-text'><h5>Title:</h5></td>
                      <td><h5 className="card-text"> {book.title}</h5></td>
                    </tr>
                    <tr>
                      <td className='card-text'><h5>Author:</h5></td>
                      <td><h5 className="card-text"> {book.author}</h5></td>
                    </tr>
                    <tr>
                      <td className='card-text'><h5>Publish Year:</h5></td>
                      <td><h5 className="card-text"> {book.publishYear}</h5></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>

    </>
  )
}

export default ShowBook