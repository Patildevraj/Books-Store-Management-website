import { Link } from 'react-router-dom'
import { AiOutlineEdit } from 'react-icons/ai'
import { BsInfoCircle } from 'react-icons/bs'
import { MdDelete } from "react-icons/md";

const BooksTable = ({books}) => {
    return (
        <>
            <div className="row table m-auto">
                <div className="col-12">
                    <table className="table table-bordered border-info">
                        <thead className='text-center'>
                            <tr className='fs-5'>
                                <th className='p-3' scope="col">SN</th>
                                <th className='p-3' scope="col">Title</th>
                                <th className='p-3' scope="col">Author</th>
                                <th className='p-3' scope="col">Publish Year</th>
                                <th className='p-3' scope="col">Operations</th>

                            </tr>
                        </thead>
                        <tbody className='text-center'>
                            {books?.map((book, index) => (
                                <tr key={book._id}>
                                    <td scope="row">{index + 1}</td>
                                    <td>{book.title}</td>
                                    <td>{book.author}</td>
                                    <td>{book.publishYear}</td>
                                    <td>
                                        <div className="row ">
                                            <div className="col-12">
                                                <Link to={`/books/details/${book._id}`}>
                                                    <BsInfoCircle className='fs-4 mx-2 text-success' />
                                                </Link>
                                                <Link to={`/books/edit/${book._id}`}>
                                                    <AiOutlineEdit className='fs-4 mx-2 text-warning' />
                                                </Link>
                                                <Link to={`/books/delete/${book._id}`}>
                                                    <MdDelete className='fs-4 mx-2 text-danger' />
                                                </Link>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            ))}

                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}

export default BooksTable