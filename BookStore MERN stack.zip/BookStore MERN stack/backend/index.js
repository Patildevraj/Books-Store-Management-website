import express from 'express'
import { PORT, mongoDBURL } from './config.js'
import mongoose from 'mongoose';
import cors from 'cors'
import MainRoutes from './routes/MainRoutes.js'

const app = express();

// middle ware for handling CORS policy (we have 2 ways to handle)
//1.Allow all origin with default of cors(*)
app.use(cors());

//2. Allow custom origin
// app.use({
//     origin:'http://localhost:3000',
//     methods:['GET','POST','PUT','DELETE'],
//     allowedHeaders:['Content-Type']
// })

app.use(express.json())

// app.get('/', async (request, response) => {

//     const book = await Book.find({})
//     return response.status(200).json({
//         count: book.length, data: book
//     })
// })

app.use('/', MainRoutes)

// app.get('/person', async (request, response) => {

//     const person = await Person.find({})
//     return response.status(200).json(person)
// })

// app.get('/:id', async(request, response) => {

//     const book = await Book.findOne({_id: request.params.id})
//     return response.status(200).json(book)
// })

mongoose.connect(mongoDBURL)
    .then(() => {
        console.log('App connected to database');
        app.listen(PORT, () => {
            console.log(`app is listening to port: ${PORT}`);
        })
    })
    .catch((error) => {
        console.log(error);
    });